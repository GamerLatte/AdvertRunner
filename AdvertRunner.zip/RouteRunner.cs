using System;
using System.Threading;
using System.Threading.Tasks;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.Text;
using Dalamud.Game.Text.SeStringHandling;
using System.Collections.Generic;

namespace AdvertRunner;

public sealed class RouteRunner
{
    private Configuration? activeCfg;
    private Delegate? chatMessageUnhandledHook;
    private Delegate? chatMessageHook;
    private readonly object hopLock = new();
    private TaskCompletionSource<string>? hopFailureTcs;
    private const string CongestionNeedle1 = "This World is experiencing congestion";
    private const string CongestionNeedle2 = "cannot visit at this time";
    private volatile bool paused;
    private readonly ManualResetEventSlim pauseGate = new(true);
    private CancellationTokenSource? cts;
    public bool IsRunning => cts is not null;
    public bool IsPaused => paused;

    public enum WorldHopResult
    {
        Success,
        AlreadyThere,
        FailedToStart,
        TimedOut,
    }

    private void DebugLog(string message)
    {
        if (activeCfg?.DebugLogging == true)
            Plugin.Log.Debug($"[AdvertRunner] {message}");
    }

    private void UserMessage(string message)
    {
        if (activeCfg?.DebugLogging == true)
            Plugin.Chat.Print($"[AdvertRunner] {message}");
    }

    public void Pause()
    {
        if (!IsRunning) return;
        paused = true;
        pauseGate.Reset();
        UserMessage("Paused.");
    }

    public void Resume()
    {
        if (!IsRunning) return;
        paused = false;
        pauseGate.Set();
        UserMessage("Resumed.");
    }

    public void Stop()
    {
        var cfg = activeCfg;
        UnhookChatMessage();
        activeCfg = null;
        lock (hopLock)
        {
            hopFailureTcs?.TrySetCanceled();
            hopFailureTcs = null;
        }

        cts?.Cancel();
        cts = null;

        paused = false;
        pauseGate.Set();
        if (cfg != null)
            ClearCheckpoint(cfg);
    }

    public void Start(Configuration cfg)
    {
        if (cfg.ResumeAfterCrash && cfg.State.InProgress)
        {
            //Let user know we found a checkpoint.
            Plugin.Chat.Print($"[AdvertRunner] Found an unfinished run checkpoint. Resuming from city #{cfg.State.NextCityIndex + 1}, world #{cfg.State.NextWorldIndex + 1}.");
        }
        else
        {
            //Fresh run
            ClearCheckpoint(cfg);
        }
        activeCfg = cfg;
        UserMessage("Debug logging enabled.");

        if (IsRunning)
        {
            UserMessage("Already running. Use /advrunner stop.");
            return;
        }

        if (!DependencyGuard.EnsureDependencies(cfg, out var error))
        {
            Plugin.Chat.Print($"[AdvertRunner] {error}");
            return;
        }

        if ((cfg.Cities?.Count ?? 0) == 0 && (cfg.Worlds?.Count ?? 0) == 0)
        {
            Plugin.Chat.Print("[AdvertRunner] No cities or worlds configured. Use /advrunner config.");
            return;
        }

        HookChatMessage();

        cts = new CancellationTokenSource();
        _ = Task.Run(() => RunAsync(cfg, cts.Token));
    }

    private async Task RunAsync(Configuration cfg, CancellationToken ct)
    {
        var startCityIndex = (cfg.ResumeAfterCrash && cfg.State.InProgress) ? cfg.State.NextCityIndex : 0;
        var startWorldIndex = (cfg.ResumeAfterCrash && cfg.State.InProgress) ? cfg.State.NextWorldIndex : 0;
        bool resumingFromCheckpoint = cfg.ResumeAfterCrash && cfg.State.InProgress;

        activeCfg = cfg;
        try
        {
            await OnFramework(() => Plugin.Chat.Print("[AdvertRunner] Starting route..."), ct);

            // Normalize macro book
            var book = (cfg.MacroBook ?? "i").Trim().ToLowerInvariant();
            if (book != "i" && book != "s") book = "i";
            var citiesSnapshot = (cfg.Cities ?? new List<string>()).ToArray();
            string[] worldsSnapshot = cfg.WorldMode switch
            {
                WorldSelectionMode.DataCenters => WorldData.ExpandDataCenters(cfg.DataCenters ?? new List<string>())
                    .ToArray(),

                _ => (cfg.Worlds?.ToArray() ?? Array.Empty<string>()),
            };


            uint? startWorldId = null;
            await OnFramework(() => startWorldId = WorldHelper.GetCurrentWorldId(), ct);

            //Track worlds we've already hopped to (by world id)
            var visitedWorldIds = new System.Collections.Generic.HashSet<uint>();
            var visitedWorldNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            string? startWorldName = null;
            await OnFramework(() => startWorldName = WorldHelper.GetCurrentWorldName(), ct);

            if (!string.IsNullOrWhiteSpace(startWorldName))
                visitedWorldNames.Add(NormWorld(startWorldName));

            if (startWorldId is not null)
                visitedWorldIds.Add(startWorldId.Value);

            // Run once on the current world
            await RunCityMacroRouteOnce(citiesSnapshot, cfg, book, ct, startCityIndex, resumingFromCheckpoint);
            resumingFromCheckpoint = false; // only force the index once

            // Hop each configured world; when it changes, re-run the route
            if (worldsSnapshot.Length > 0)
            {
                for (int wi = startWorldIndex; wi < worldsSnapshot.Length; wi++)
                {
                    ct.ThrowIfCancellationRequested();
                    await WaitIfPaused(ct);

                    var rawWorld = worldsSnapshot[wi];
                    var world = (rawWorld ?? "").Trim();
                    if (string.IsNullOrWhiteSpace(world))
                        continue;

                    // Skip starting world if it appears in list (your existing visited-world logic may already do this)
                    if (visitedWorldNames.Contains(NormWorld(world)))
                    {
                        UserMessage($"Skipping world '{world}' (already visited / starting world).");
                        continue;
                    }

                    var hop = await HopWorldAndWait(world, ct);
                    if (hop != WorldHopResult.Success)
                    {
                        // Important: if hop failed, cancel any in-progress /li before trying next world
                        await CancelLifestream(ct);
                        UserMessage($"Skipping world '{world}' due to hop failure.");
                        continue;
                    }

                    string? nowName = null;
                    await OnFramework(() => nowName = WorldHelper.GetCurrentWorldName(), ct);
                    if (!string.IsNullOrWhiteSpace(nowName))
                        visitedWorldNames.Add(NormWorld(nowName));

                    // ✅ Precise checkpoint: next world is wi+1, next city resets to 0
                    await CheckpointAsync(cfg, nextCityIndex: 0, nextWorldIndex: wi + 1, ct);

                    // Re-run city route on the new world from beginning
                    await RunCityMacroRouteOnce(citiesSnapshot, cfg, book, ct, 0, false);
                }
            }

        await ApplyEndDestination(cfg, ct);
        await OnFramework(() => Plugin.Chat.Print("[AdvertRunner] Route complete."), ct);
        ClearCheckpoint(cfg);
        }
        catch (OperationCanceledException)
        {
        await OnFramework(() => Plugin.Chat.Print("[AdvertRunner] Stopped."), CancellationToken.None);
        }
        catch (Exception ex)
        {
            await OnFramework(() =>
            {
                Plugin.Log.Error(ex, "RouteRunner crashed");
                Plugin.Chat.Print("[AdvertRunner] Error occurred; check logs.");
            }, CancellationToken.None);
        }
        finally
        {
            UnhookChatMessage();
            activeCfg = null;
            lock (hopLock)
            {
                hopFailureTcs?.TrySetCanceled();
                hopFailureTcs = null;
            }
            cts = null;
        }
    }

    /// <summary>
    /// Runs the city -> macro loop exactly once, starting from the player's current city if it matches the list,
    /// and ensuring no city is repeated.
    /// </summary>
    private async Task RunCityMacroRouteOnce(string[] cities, Configuration cfg, string book, CancellationToken ct, int startAtIndex, bool forceStartInd)
    {
        if (cities is null || cities.Length == 0)
            return;

        string? place = null;
        int startIdx = -1;

        await OnFramework(() =>
        {
            place = LocationHelper.GetCurrentPlaceName();
            startIdx = LocationHelper.FindMatchingCityIndex(cities, place);
        }, ct);

        if (forceStartInd)
        {
            startIdx = Math.Clamp(startAtIndex, 0, cities.Length - 1);
        }


        await OnFramework(() =>
        {
            UserMessage(place != null
                ? $"Current location: {place}"
                : "Current location: (unknown)");

            UserMessage(startIdx >= 0
                ? $"In configured city: '{cities[startIdx]}'. Will start there (no repeat)."
                : "Not in a configured city; starting from the first city.");
        }, ct);

        // If we are already in a listed city, run macro immediately (no /li to the same place)
        if (startIdx >= 0)
        {
            await OnFramework(() =>
            {
                UserMessage($"CMD: /runmacro {cfg.MacroNumber} {book}");
                Plugin.CommandManager.ProcessCommand($"/runmacro {cfg.MacroNumber} {book}");
            }, ct);

            await WaitForMacroComplete(ct);
            await CheckpointAsync(cfg, nextCityIndex: (startIdx + 1) % cities.Length, nextWorldIndex: cfg.State.NextWorldIndex, ct);
        }

        // Visit remaining cities exactly once, in rotated order
        int count = cities.Length;
        int first = startIdx >= 0 ? (startIdx + 1) % count : 0;

        for (int offset = 0; offset < count; offset++)
        {
            ct.ThrowIfCancellationRequested();

            int idx = (first + offset) % count;

            // Skip the current city if it matched (avoid repeat)
            if (idx == startIdx) continue;

            var city = (cities[idx] ?? "").Trim();
            if (string.IsNullOrWhiteSpace(city)) continue;

            await WaitIfPaused(ct);
            var beforeTerritory = await GetTerritoryType(ct);
            await OnFramework(() =>
            {
                UserMessage($"CMD: /li {city}");
                Plugin.CommandManager.ProcessCommand($"/li {city}");
            }, ct);

            await WaitForTeleportComplete(beforeTerritory, ct);

            await WaitIfPaused(ct);
            await OnFramework(() =>
            {
                UserMessage($"CMD: /runmacro {cfg.MacroNumber} {book}");
                Plugin.CommandManager.ProcessCommand($"/runmacro {cfg.MacroNumber} {book}");
            }, ct);

            await WaitForMacroComplete(ct);
            await CheckpointAsync(cfg, nextCityIndex: (idx + 1) % cities.Length, nextWorldIndex: cfg.State.NextWorldIndex, ct);
        }
    }

    private async Task<WorldHopResult> HopWorldAndWait(string world, CancellationToken ct)
    {
        await WaitIfPaused(ct);

        uint? beforeWorld = null;
        await OnFramework(() => beforeWorld = WorldHelper.GetCurrentWorldId(), ct);

        // Create a fresh congestion-failure latch for THIS hop
        TaskCompletionSource<string> localFail;
        lock (hopLock)
        {
            hopFailureTcs?.TrySetCanceled();
            hopFailureTcs = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
            localFail = hopFailureTcs;
        }

        await OnFramework(() =>
        {
            UserMessage($"CMD: /li {world}");
            Plugin.CommandManager.ProcessCommand($"/li {world}");
        }, ct);

        while (true)
        {
            ct.ThrowIfCancellationRequested();
            await WaitIfPaused(ct);

            // Success: world changed
            uint? nowWorld = null;
            await OnFramework(() => nowWorld = WorldHelper.GetCurrentWorldId(), ct);

            if (beforeWorld is not null && nowWorld is not null && nowWorld.Value != beforeWorld.Value)
            {
                UserMessage($"World changed ({beforeWorld} → {nowWorld}), waiting 2 seconds to settle.");
                await Task.Delay(4000, ct);
                lock (hopLock) 
                    hopFailureTcs = null;
                return WorldHopResult.Success;
            }

            // Failure: congestion message detected
            if (localFail.Task.IsCompleted)
            {
                string msg;
                try { msg = localFail.Task.Result; }
                catch { msg = "World congestion prevented visiting."; }

                await OnFramework(() => UserMessage($"World visit blocked: {msg}"), ct);

                // Cancel the pending /li attempt so the next one doesn't stack
                await CancelLifestream(ct);

                lock (hopLock) hopFailureTcs = null;
                return WorldHopResult.FailedToStart;
            }

            await Task.Delay(250, ct);
        }
    }

    private static Task OnFramework(Action action, CancellationToken ct)
    {
        var tcs = new TaskCompletionSource<bool>();

        Plugin.Framework.RunOnFrameworkThread(() =>
        {
            if (ct.IsCancellationRequested)
            {
                tcs.TrySetCanceled(ct);
                return;
            }

            try
            {
                action();
                tcs.TrySetResult(true);
            }
            catch (Exception ex)
            {
                tcs.TrySetException(ex);
            }
        });

        return tcs.Task;
    }

    private async Task WaitForTeleportComplete(uint territoryBefore, CancellationToken ct)
    {
        // We consider a teleport "complete" when:
        // - we observed a loading/between-areas state OR territory changed
        // - and now we are NOT between areas AND territory is stable
        var start = DateTime.UtcNow;
        var timeout = TimeSpan.FromSeconds(90);

        bool sawBetweenAreas = false;

        while ((DateTime.UtcNow - start) < timeout)
        {
            ct.ThrowIfCancellationRequested();

            bool betweenAreas = false;
            uint territoryNow = territoryBefore;

            await OnFramework(() =>
            {
                betweenAreas =
                    Plugin.Condition[ConditionFlag.BetweenAreas] ||
                    Plugin.Condition[ConditionFlag.BetweenAreas51];

                territoryNow = Plugin.ClientState.TerritoryType;
            }, ct);

            if (betweenAreas)
                sawBetweenAreas = true;

            // Territory change is also a strong signal that the teleport started
            bool territoryChanged = territoryNow != territoryBefore;

            // Complete when we're no longer loading and we've either seen loading or changed territory
            if (!betweenAreas && (sawBetweenAreas || territoryChanged))
            {
                // small “settle” delay helps avoid immediate follow-up firing too early
                await Task.Delay(250, ct);
                return;
            }

            await Task.Delay(200, ct);
        }

        await OnFramework(() => UserMessage("Teleport completion timed out; continuing."), ct);
    }

    private async Task<uint> GetTerritoryType(CancellationToken ct)
    {
        uint t = 0;
        await OnFramework(() => t = Plugin.ClientState.TerritoryType, ct);
        return t;
    }

    private static string NormWorld(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return "";
        s = s.Trim().ToLowerInvariant();
        // remove punctuation/spaces to make matching forgiving
        var chars = s.ToCharArray();
        var buf = new System.Text.StringBuilder(chars.Length);
        foreach (var ch in chars)
        {
            if (char.IsLetterOrDigit(ch))
                buf.Append(ch);
        }
        return buf.ToString();
    }

    private async Task ApplyEndDestination(Configuration cfg, CancellationToken ct)
    {
        string? destination = cfg.EndDestination switch
        {
            EndDestinationMode.None => null,
            EndDestinationMode.Home => "home",
            EndDestinationMode.Fc => "fc",
            EndDestinationMode.Custom => (cfg.CustomEndDestination ?? "").Trim(),
            _ => null,
        };

        if (string.IsNullOrWhiteSpace(destination))
            return;

        await OnFramework(() =>
        {
            Plugin.Chat.Print($"[AdvertRunner] Ending at: {destination}");
            Plugin.CommandManager.ProcessCommand($"/li {destination}");
        }, ct);

        // Optional: if you want, we can wait for teleport complete here too.
        // For now, we'll just fire it and let it happen.
    }

    private async Task WaitForMacroComplete(CancellationToken ct)
    {
        // 1) Give it a moment to actually start
        var start = DateTime.UtcNow;
        var startTimeout = TimeSpan.FromSeconds(2);

        bool started = false;

        while ((DateTime.UtcNow - start) < startTimeout)
        {
            ct.ThrowIfCancellationRequested();

            bool running = false;
            await OnFramework(() => running = MacroHelper.IsMacroRunning(), ct);

            if (running)
            {
                started = true;
                break;
            }

            await Task.Delay(50, ct);
        }

        // If it never started (bad macro slot, blocked, etc.) don’t hang; just continue
        if (!started)
            return;

        // 2) Wait until it stops (with a hard max timeout)
        var stopStart = DateTime.UtcNow;
        var stopTimeout = TimeSpan.FromSeconds(30); // tweak if you have very long macros

        while ((DateTime.UtcNow - stopStart) < stopTimeout)
        {
            ct.ThrowIfCancellationRequested();

            bool running = false;
            await OnFramework(() => running = MacroHelper.IsMacroRunning(), ct);

            if (!running)
            {
                // tiny settle delay to avoid firing next command on the same frame
                await Task.Delay(150, ct);
                return;
            }

            await Task.Delay(50, ct);
        }

        await OnFramework(() => UserMessage("Macro completion timed out; continuing."), ct);
    }

    private async Task WaitIfPaused(CancellationToken ct)
    {
        while (paused)
        {
            ct.ThrowIfCancellationRequested();
            await Task.Delay(100, ct);
        }
    }


    private async Task CancelLifestream(CancellationToken ct)
    {
        await OnFramework(() =>
        {
            UserMessage("World transfer failed; sending /li stop...");
            Plugin.CommandManager.ProcessCommand("/li stop");
        }, ct);

        // Give Lifestream a moment to clear its queue/state
        await Task.Delay(250, ct);

        // Optional but safe: wait until we’re not mid-transition
        await WaitForNotBetweenAreas(ct);
    }

    private async Task WaitForNotBetweenAreas(CancellationToken ct)
    {
        var start = DateTime.UtcNow;
        var timeout = TimeSpan.FromSeconds(10);

        while ((DateTime.UtcNow - start) < timeout)
        {
            ct.ThrowIfCancellationRequested();

            bool betweenAreas = false;
            await OnFramework(() =>
            {
                betweenAreas =
                    Plugin.Condition[Dalamud.Game.ClientState.Conditions.ConditionFlag.BetweenAreas] ||
                    Plugin.Condition[Dalamud.Game.ClientState.Conditions.ConditionFlag.BetweenAreas51];
            }, ct);

            if (!betweenAreas)
                return;

            await Task.Delay(100, ct);
        }
    }

    private void HookChatMessage()
{
    if (chatMessageHook != null || chatMessageUnhandledHook != null)
        return;

    HookOne("ChatMessage", ref chatMessageHook);
    HookOne("ChatMessageUnhandled", ref chatMessageUnhandledHook); // may not exist on all builds; HookOne handles that
}

private void HookOne(string eventName, ref Delegate? storage)
    {
        var chat = Plugin.Chat;
        var evt = chat.GetType().GetEvent(eventName);
        if (evt == null)
            return; // fine: not all builds have all events

        var handlerType = evt.EventHandlerType!;
        var invoke = handlerType.GetMethod("Invoke")!;
        var parameters = invoke.GetParameters();

        var paramExprs = new System.Linq.Expressions.ParameterExpression[parameters.Length];
        for (int i = 0; i < parameters.Length; i++)
            paramExprs[i] = System.Linq.Expressions.Expression.Parameter(parameters[i].ParameterType, parameters[i].Name);

        var calls = new List<System.Linq.Expressions.Expression>();

        // Build: { OnChatText(seStr1.TextValue); OnChatText(seStr2.TextValue); ... }
        for (int i = 0; i < paramExprs.Length; i++)
        {
            var p = paramExprs[i];
            var t = p.Type;

            System.Linq.Expressions.Expression? se = null;

            if (t == typeof(SeString))
                se = p;
            else if (t.IsByRef && t.GetElementType() == typeof(SeString))
                se = System.Linq.Expressions.Expression.Convert(p, typeof(SeString));

            if (se == null)
                continue;

            var textValueProp = System.Linq.Expressions.Expression.Property(se, nameof(SeString.TextValue));

            var call = System.Linq.Expressions.Expression.Call(
                System.Linq.Expressions.Expression.Constant(this),
                typeof(RouteRunner).GetMethod(nameof(OnChatText),
                    System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)!,
                textValueProp
            );

            calls.Add(call);
        }

        if (calls.Count == 0)
            throw new InvalidOperationException($"{eventName} delegate did not contain any SeString parameters.");

        // Return type is void; block is fine
        var body = System.Linq.Expressions.Expression.Block(calls);

        var lambda = System.Linq.Expressions.Expression.Lambda(handlerType, body, paramExprs);
        storage = lambda.Compile();

        evt.AddEventHandler(chat, storage);
    }

    private void UnhookChatMessage()
    {
        var chat = Plugin.Chat;

        if (chatMessageHook != null)
        {
            var evt = chat.GetType().GetEvent("ChatMessage");
            evt?.RemoveEventHandler(chat, chatMessageHook);
            chatMessageHook = null;
        }

        if (chatMessageUnhandledHook != null)
        {
            var evt = chat.GetType().GetEvent("ChatMessageUnhandled");
            evt?.RemoveEventHandler(chat, chatMessageUnhandledHook);
            chatMessageUnhandledHook = null;
        }
    }

    private void OnChatText(string? text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return;

        // Only care while we are actively waiting for a hop failure/success.
        TaskCompletionSource<string>? tcs;
        lock (hopLock)
            tcs = hopFailureTcs;

        if (tcs == null)
            return;

        // Normalize whitespace (handles line breaks)
        var norm = System.Text.RegularExpressions.Regex.Replace(text, @"\s+", " ").Trim();

        // TEMP DEBUG: confirm we are seeing the actual error line
        DebugLog($"Chat seen during hop: {norm}");

        if (norm.Contains("experiencing congestion", StringComparison.OrdinalIgnoreCase) &&
            norm.Contains("cannot visit", StringComparison.OrdinalIgnoreCase))
        {
            lock (hopLock)
            {
                hopFailureTcs?.TrySetResult(norm);
            }
        }
    }

    private void ClearCheckpoint(Configuration cfg)
    {
        cfg.State.Clear();
        cfg.Save();
    }

    private async Task CheckpointAsync(Configuration cfg, int nextCityIndex, int nextWorldIndex, CancellationToken ct)
    {
        string worldName = "";
        uint worldId = 0;

        await OnFramework(() =>
        {
            worldName = WorldHelper.GetCurrentWorldName() ?? "";
            worldId = WorldHelper.GetCurrentWorldId() ?? 0;
        }, ct);

        cfg.State.InProgress = true;
        cfg.State.NextCityIndex = Math.Max(0, nextCityIndex);
        cfg.State.NextWorldIndex = Math.Max(0, nextWorldIndex);
        cfg.State.WorldNameAtCheckpoint = worldName;
        cfg.State.WorldIdAtCheckpoint = worldId;
        cfg.State.LastCheckpointUnixSeconds = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        cfg.Save();

        DebugLog($"Checkpoint saved: nextCity={cfg.State.NextCityIndex}, nextWorld={cfg.State.NextWorldIndex}, world={worldName} ({worldId})");
    }
    public bool HasCheckpoint(Configuration cfg)
    {
        return cfg.State is not null && cfg.State.InProgress;
    }

    public void ResumeFromCheckpoint(Configuration cfg)
    {
        if (IsRunning)
        {
            UserMessage("Already running.");
            return;
        }

        if (!HasCheckpoint(cfg))
        {
            UserMessage("No checkpoint to resume from.");
            return;
        }

        Start(cfg); // Start() already respects ResumeAfterCrash + State
    }

}
