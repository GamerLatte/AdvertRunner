using Dalamud.Game.Command;
using Dalamud.IoC;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using AdvertRunner.Ui;
using System.Diagnostics.Contracts;
using System.Text.Json.Serialization;

namespace AdvertRunner;

public sealed class Plugin : IDalamudPlugin
{
    [PluginService] public static IDalamudPluginInterface PluginInterface { get; private set; } = null!;
    [PluginService] public static ICommandManager CommandManager { get; private set; } = null!;
    [PluginService] public static IChatGui Chat { get; private set; } = null!;
    [PluginService] public static IPluginLog Log { get; private set; } = null!;
    [PluginService] public static IObjectTable ObjectTable { get; private set; } = null!;
    [PluginService] public static IFramework Framework { get; private set; } = null!;
    [PluginService] public static IClientState ClientState { get; private set; } = null!;
    [PluginService] public static IDataManager DataManager { get; private set; } = null!;
    [PluginService] public static ICondition Condition { get; private set; } = null!;

    public string Name => "AdvertRunner";
    private const string Command = "/advrunner";
    private readonly UiManager ui;
    private readonly RouteRunner runner = new();
    private readonly Configuration config;

    public Plugin()
    {
        config = PluginInterface.GetPluginConfig() as Configuration ?? new Configuration();
        config.Save();

        ui = new UiManager(
            config,
            isRunning: () => runner.IsRunning,
            isPaused: () => runner.IsPaused,
            hasCheckpoint: () => runner.HasCheckpoint(config),
            start: () =>
            {
                if (ObjectTable.LocalPlayer == null)
                {
                    Chat.Print("[AdvertRunner] You must be logged in to start.");
                    return;
                }
                runner.Start(config);
            },
            resumeFromCheckpoint: () => runner.ResumeFromCheckpoint(config),
            stop: () => runner.Stop(),
            pause: () => runner.Pause(),
            resume: () => runner.Resume()
        );

        PluginInterface.UiBuilder.Draw += ui.Draw;
        PluginInterface.UiBuilder.OpenConfigUi += ui.OpenConfig;

        CommandManager.AddHandler(Command, new CommandInfo(OnCommand)
        {
            HelpMessage = "AdvertRunner: /advrunner start | stop | pause | resume | status | config"
        });

        Chat.Print("[AdvertRunner] Loaded. Use /advrunner start");
    }

    public void Dispose()
    {
        runner.Stop();

        PluginInterface.UiBuilder.Draw -= ui.Draw;
        PluginInterface.UiBuilder.OpenConfigUi -= ui.OpenConfig;
        ui.Dispose();

        CommandManager.RemoveHandler(Command);
    }

    private void OnCommand(string command, string args)
    {
        args = (args ?? "").Trim().ToLowerInvariant();

        switch (args)
        {
            case "start":
                if (ObjectTable.LocalPlayer == null)
                {
                    Chat.Print("[AdvertRunner] You must be logged in to start.");
                    return;
                }
                runner.Start(config);
                break;

            case "stop":
                runner.Stop();
                break;

            case "status":
                Chat.Print(runner.IsRunning ? "[AdvertRunner] Running." : "[AdvertRunner] Idle.");
                break;

            case "config":
                ui.ToggleConfig();
                break;

            case "pause":
                runner.Pause();
                break;

            case "resume":
                runner.Resume();
                break;

            default:
                Chat.Print("[AdvertRunner] Usage: /advrunner start | stop | status | config");
                break;
        }
    }
}
