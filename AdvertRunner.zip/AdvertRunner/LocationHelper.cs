using System;
using System.Globalization;
using System.Linq;
using Lumina.Excel.Sheets;

namespace AdvertRunner;

public static class LocationHelper
{
    public static string? GetCurrentPlaceName()
    {
        // TerritoryType is a ushort territory id from IClientState. :contentReference[oaicite:2]{index=2}
        var territoryId = Plugin.ClientState.TerritoryType;

        var sheet = Plugin.DataManager.GameData.GetExcelSheet<TerritoryType>();
        if (sheet == null) return null;

        var territory = sheet.GetRow(territoryId);
        if (territory.RowId == 0) return null;

        // Example usage of TerritoryType.PlaceName seen in real plugins. :contentReference[oaicite:3]{index=3}
        return territory.PlaceName.ValueNullable?.Name.ToString();
    }

    // Normalize so "Ul'dah - Steps of Nald" matches "uldah"
    public static string Norm(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return "";
        s = s.ToLowerInvariant();

        // keep letters/digits only
        return new string(s.Where(char.IsLetterOrDigit).ToArray());
    }

    public static int FindMatchingCityIndex(System.Collections.Generic.IReadOnlyList<string> cities, string? currentPlaceName)
    {
        if (cities.Count == 0 || string.IsNullOrWhiteSpace(currentPlaceName))
            return -1;

        var cur = Norm(currentPlaceName);

        for (int i = 0; i < cities.Count; i++)
        {
            var cityRaw = cities[i] ?? "";
            var city = Norm(cityRaw);

            if (city.Length == 0) continue;

            // direct containment (works if user enters "limsa", "grid", "uldah", or full names)
            if (cur.Contains(city))
                return i;

            // common aliases for convenience
            if (IsAliasMatch(city, cur))
                return i;
        }

        return -1;
    }

    private static bool IsAliasMatch(string cityNorm, string curNorm)
    {
        // user might type "grid", but place name contains "gridania"
        if (cityNorm == "grid" || cityNorm == "gridania")
            return curNorm.Contains("gridania");

        if (cityNorm == "limsa" || cityNorm == "limsalominsa")
            return curNorm.Contains("limsa") || curNorm.Contains("loms") || curNorm.Contains("limsalominsa");

        if (cityNorm == "uldah" || cityNorm == "ulda")
            return curNorm.Contains("uldah") || curNorm.Contains("stepsofnald") || curNorm.Contains("stepsofthal");

        return false;
    }
}
