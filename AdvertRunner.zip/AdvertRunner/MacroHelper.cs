using FFXIVClientStructs.FFXIV.Client.UI.Shell;

namespace AdvertRunner;

public static unsafe class MacroHelper
{
    /// <summary>
    /// Returns the current macro line index, or -1 when no macro is running.
    /// </summary>
    public static int GetMacroCurrentLine()
    {
        var shell = RaptureShellModule.Instance();
        if (shell == null)
            return -1;

        // In most client versions, MacroCurrentLine is -1 when idle, >= 0 while running.
        return shell->MacroCurrentLine;
    }

    public static bool IsMacroRunning() => GetMacroCurrentLine() >= 0;
}
