using System;
using Dalamud.Interface.Windowing;

namespace AdvertRunner.Ui;

public sealed class UiManager
{
    private readonly WindowSystem windowSystem = new("AdvertRunner");
    private readonly ConfigWindow configWindow;

    public UiManager(
        Configuration config,
        Func<bool> isRunning,
        Func<bool> isPaused,
        Func<bool> hasCheckpoint,
        Action start,
        Action resumeFromCheckpoint,
        Action stop,
        Action pause,
        Action resume)
    {
        configWindow = new ConfigWindow(
            config,
            isRunning,
            isPaused,
            hasCheckpoint,
            start,
            resumeFromCheckpoint,
            stop,
            pause,
            resume
        );
        windowSystem.AddWindow(configWindow);
    }

    public void Draw() => windowSystem.Draw();

    public void ToggleConfig() => configWindow.IsOpen = !configWindow.IsOpen;

    public void OpenConfig() => configWindow.IsOpen = true;

    public void Dispose()
    {
        windowSystem.RemoveAllWindows();
    }
}
