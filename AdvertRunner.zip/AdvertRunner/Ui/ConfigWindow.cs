using System;
using System.Numerics;
using Dalamud.Interface.Windowing;
using Dalamud.Bindings.ImGui;

namespace AdvertRunner.Ui;

public sealed class ConfigWindow : Window
{
    private readonly Configuration config;
    private readonly Func<bool> isRunning;
    private readonly Func<bool> isPaused;
    private readonly Func<bool> hasCheckpoint;
    private readonly Action resumeFromCheckpoint;
    private readonly Action pause;
    private readonly Action resume;
    private readonly Action start;
    private readonly Action stop;

    // Temporary input buffers
    private string newCity = string.Empty;
    private string customEnd = string.Empty;
    private int dcChoiceIndex = 0;
    private int worldChoiceIndex = 0;
    private string[] allDcs = Array.Empty<string>();
    private string[] allWorlds = Array.Empty<string>();

    public ConfigWindow(
        Configuration config,
        Func<bool> isRunning,
        Func<bool> isPaused,
        Func<bool> hasCheckpoint,
        Action start,
        Action resumeFromCheckpoint,
        Action stop,
        Action pause,
        Action resume) : base("AdvertRunner Config")
    {
        this.config = config;
        this.isRunning = isRunning;
        this.isPaused = isPaused;
        this.hasCheckpoint = hasCheckpoint;
        this.resumeFromCheckpoint = resumeFromCheckpoint;
        this.start = start;
        this.stop = stop;
        this.pause = pause;
        this.resume = resume;

        customEnd = config.CustomEndDestination ?? "";

        Size = new Vector2(560, 560);
        SizeCondition = ImGuiCond.FirstUseEver;
        RespectCloseHotkey = true;
    }

    public override void Draw()
    {
        allDcs = WorldData.GetAllDataCenters();
        allWorlds = WorldData.GetAllWorlds();

        DrawRunnerControls();
        ImGui.Separator();

        ImGui.TextWrapped("Configure the route builder: each City becomes '/li <city>' then '/runmacro <macro> <i|s>'. Worlds are used as world hops and will restart the city route after changing worlds.");
        ImGui.Separator();

        DrawMacroSection();
        ImGui.Separator();

        DrawEndDestinationSection();
        ImGui.Separator();

        DrawCitiesSection();
        ImGui.Separator();

        DrawWorldsSection();
        ImGui.Separator();

        if (ImGui.Button("Save"))
        {
            // Keep config in sync for custom end destination even if user didn’t toggle focus away
            config.CustomEndDestination = customEnd;

            config.Save();
            Plugin.Chat.Print("[AdvertRunner] Config saved.");
        }

        ImGui.SameLine();
        if (ImGui.Button("Close"))
            IsOpen = false;
        
        ImGui.Separator();   
        DrawDebugSection();     
    }

    private void DrawRunnerControls()
    {
        ImGui.Text("Controls");

        bool running = isRunning();
        bool paused = isPaused();
        bool canResumeCheckpoint = hasCheckpoint();

        ImGui.Text(running ? "Status: Running" : "Status: Idle");

        // Start / Stop / Pause / Resume row
        if (!running)
        {
            if (ImGui.Button("Start Route"))
            {
                config.CustomEndDestination = customEnd;
                config.Save();
                start();
            }
        }
        else
        {
            if (!paused)
            {
                if (ImGui.Button("Pause"))
                    pause();
            }
            else
            {
                if (ImGui.Button("Resume"))
                    resume();
            }

            ImGui.SameLine();
            if (ImGui.Button("Stop"))
                stop();
        }

        // ---- Resume from Checkpoint (ALWAYS visible) ----
        ImGui.SameLine();

        if (!canResumeCheckpoint)
            ImGui.BeginDisabled();

        string label = canResumeCheckpoint
            ? "Resume from Checkpoint"
            : "No Checkpoints";

        if (ImGui.Button(label))
        {
            resumeFromCheckpoint();
        }

        if (!canResumeCheckpoint)
            ImGui.EndDisabled();

        ImGui.SameLine();
        ImGui.TextDisabled("(Use /advrunner start|stop|pause|resume)");
    }

    private void DrawMacroSection()
    {
        ImGui.Text("Macro");

        int macroSet = config.MacroNumber;
        if (ImGui.InputInt("Macro Number", ref macroSet))
            config.MacroNumber = Math.Clamp(macroSet, 1, 99);

        int scopeIndex = config.MacroBook?.Trim().ToLowerInvariant() == "s" ? 1 : 0;
        if (ImGui.RadioButton("Individual (i)", scopeIndex == 0)) scopeIndex = 0;
        ImGui.SameLine();
        if (ImGui.RadioButton("Shared (s)", scopeIndex == 1)) scopeIndex = 1;
        config.MacroBook = scopeIndex == 1 ? "s" : "i";
    }

    private void DrawEndDestinationSection()
    {
        ImGui.Text("End Destination");

        int mode = (int)config.EndDestination;

        if (ImGui.RadioButton("None", mode == (int)EndDestinationMode.None))
            mode = (int)EndDestinationMode.None;
        ImGui.SameLine();
        if (ImGui.RadioButton("Home", mode == (int)EndDestinationMode.Home))
            mode = (int)EndDestinationMode.Home;
        ImGui.SameLine();
        if (ImGui.RadioButton("FC", mode == (int)EndDestinationMode.Fc))
            mode = (int)EndDestinationMode.Fc;
        ImGui.SameLine();
        if (ImGui.RadioButton("Custom", mode == (int)EndDestinationMode.Custom))
            mode = (int)EndDestinationMode.Custom;

        config.EndDestination = (EndDestinationMode)mode;

        if (config.EndDestination == EndDestinationMode.Custom)
        {
            ImGui.SetNextItemWidth(380);
            ImGui.InputText("Custom Destination", ref customEnd, 64);

            // Keep config updated live
            config.CustomEndDestination = customEnd;

            ImGui.TextWrapped("Warning: Custom must be a real Lifestream destination OR exist in your Lifestream address book.");
        }
    }

    private void DrawCitiesSection()
    {
        ImGui.Text("Cities (visited in order)");

        for (int i = 0; i < config.Cities.Count; i++)
        {
            ImGui.PushID($"city_{i}");

            string value = config.Cities[i] ?? "";
            ImGui.SetNextItemWidth(380);
            if (ImGui.InputText("##city", ref value, 64))
                config.Cities[i] = value;

            ImGui.SameLine();
            if (ImGui.Button("Up") && i > 0)
                (config.Cities[i - 1], config.Cities[i]) = (config.Cities[i], config.Cities[i - 1]);

            ImGui.SameLine();
            if (ImGui.Button("Down") && i < config.Cities.Count - 1)
                (config.Cities[i + 1], config.Cities[i]) = (config.Cities[i], config.Cities[i + 1]);

            ImGui.SameLine();
            if (ImGui.Button("Remove"))
            {
                config.Cities.RemoveAt(i);
                ImGui.PopID();
                break;
            }

            ImGui.PopID();
        }

        ImGui.SetNextItemWidth(380);
        ImGui.InputText("Add City", ref newCity, 64);
        ImGui.SameLine();
        if (ImGui.Button("Add##city"))
        {
            var c = (newCity ?? "").Trim();
            if (!string.IsNullOrWhiteSpace(c))
                config.Cities.Add(c);
            newCity = string.Empty;
        }
    }

    private void DrawWorldsSection()
    {
        ImGui.Text("World Routing");

        // Mode toggle
        int mode = (int)config.WorldMode;
        if (ImGui.RadioButton("Use Worlds", mode == (int)WorldSelectionMode.Worlds)) mode = (int)WorldSelectionMode.Worlds;
        ImGui.SameLine();
        if (ImGui.RadioButton("Use Data Centers", mode == (int)WorldSelectionMode.DataCenters)) mode = (int)WorldSelectionMode.DataCenters;
        config.WorldMode = (WorldSelectionMode)mode;

        ImGui.Separator();

        if (config.WorldMode == WorldSelectionMode.DataCenters)
            DrawDataCenterPicker();
        else
            DrawWorldPicker();
    }   

    private void DrawDataCenterPicker()
    {
        ImGui.Text("Data Centers (visited in order)");

        // Existing DC list with Up/Down/Remove
        for (int i = 0; i < config.DataCenters.Count; i++)
        {
            ImGui.PushID($"dc_{i}");

            ImGui.TextUnformatted(config.DataCenters[i] ?? "");

            ImGui.SameLine();
            if (ImGui.Button("Up") && i > 0)
                (config.DataCenters[i - 1], config.DataCenters[i]) = (config.DataCenters[i], config.DataCenters[i - 1]);

            ImGui.SameLine();
            if (ImGui.Button("Down") && i < config.DataCenters.Count - 1)
                (config.DataCenters[i + 1], config.DataCenters[i]) = (config.DataCenters[i], config.DataCenters[i + 1]);

            ImGui.SameLine();
            if (ImGui.Button("Remove"))
            {
                config.DataCenters.RemoveAt(i);
                ImGui.PopID();
                break;
            }

            ImGui.PopID();
        }

        // Dropdown + Add
        if (allDcs.Length == 0)
        {
            ImGui.TextWrapped("WorldData.DataCenters is empty. Paste your DC/world mapping into WorldData.cs to enable dropdowns.");
            return;
        }   

        dcChoiceIndex = Math.Clamp(dcChoiceIndex, 0, allDcs.Length - 1);
        ImGui.SetNextItemWidth(380);
        ImGui.Combo("Add Data Center", ref dcChoiceIndex, allDcs, allDcs.Length);

        ImGui.SameLine();
        if (ImGui.Button("Add##dc"))
        {
            var dc = allDcs[dcChoiceIndex];
            if (!string.IsNullOrWhiteSpace(dc))
                config.DataCenters.Add(dc);
        }

        ImGui.TextWrapped("Note: selecting Data Centers expands into their Worlds automatically at runtime.");
    }

    private void DrawWorldPicker()
    {
        ImGui.Text("Worlds (visited in order)");

        // Existing World list with Up/Down/Remove
        for (int i = 0; i < config.Worlds.Count; i++)
        {
            ImGui.PushID($"world_{i}");

            ImGui.TextUnformatted(config.Worlds[i] ?? "");

            ImGui.SameLine();
            if (ImGui.Button("Up") && i > 0)
                (config.Worlds[i - 1], config.Worlds[i]) = (config.Worlds[i], config.Worlds[i - 1]);

            ImGui.SameLine();
            if (ImGui.Button("Down") && i < config.Worlds.Count - 1)
                (config.Worlds[i + 1], config.Worlds[i]) = (config.Worlds[i], config.Worlds[i + 1]);

            ImGui.SameLine();
            if (ImGui.Button("Remove##world"))
            {
                config.Worlds.RemoveAt(i);
                ImGui.PopID();
                break;
            }

            ImGui.PopID();
        }

        // Dropdown + Add
        if (allWorlds.Length == 0)
        {
            ImGui.TextWrapped("World list is empty. Paste your DC/world mapping into WorldData.cs to enable dropdowns.");
            return;
        }

        worldChoiceIndex = Math.Clamp(worldChoiceIndex, 0, allWorlds.Length - 1);
        ImGui.SetNextItemWidth(380);
        ImGui.Combo("Add World", ref worldChoiceIndex, allWorlds, allWorlds.Length);

        ImGui.SameLine();
        if (ImGui.Button("Add##world"))
        {
            var w = allWorlds[worldChoiceIndex];
            if (!string.IsNullOrWhiteSpace(w))
                config.Worlds.Add(w);
        }
    }

    private void DrawDebugSection()
    {
        ImGui.Text("Debug");

        bool dbg = config.DebugLogging;
        if (ImGui.Checkbox("Enable Debug Logging", ref dbg))
        {
            config.DebugLogging = dbg;
            config.Save(); // optional, but nice so it sticks immediately

            Plugin.Chat.Print(dbg
                ? "[AdvertRunner] Debug logging enabled."
                : "[AdvertRunner] Debug logging disabled.");
        }

        ImGui.TextDisabled("Controls extra logging in Dalamud log + (optionally) chat messages.");
    }

}
