using System;
using System.Linq;

namespace AdvertRunner;

public static class DependencyGuard
{
    public static bool EnsureDependencies(Configuration cfg, out string? errorMessage)
    {
        errorMessage = null;

        bool needsLifestream =
            (cfg.Cities?.Any(c => !string.IsNullOrWhiteSpace(c)) ?? false) ||
            (cfg.Worlds?.Any(w => !string.IsNullOrWhiteSpace(w)) ?? false);

        if (!needsLifestream)
            return true;

        var lifestream = Plugin.PluginInterface.InstalledPlugins
            .FirstOrDefault(p =>
                string.Equals(p.InternalName, "Lifestream", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(p.Name, "Lifestream", StringComparison.OrdinalIgnoreCase));

        if (lifestream is null)
        {
            errorMessage = "This route uses /li, but Lifestream is not installed. Install/enable Lifestream or remove cities/worlds.";
            return false;
        }

        if (!lifestream.IsLoaded)
        {
            errorMessage = "This route uses /li, but Lifestream is installed and not enabled. Enable it in /xlplugins.";
            return false;
        }

        return true;
    }
}
