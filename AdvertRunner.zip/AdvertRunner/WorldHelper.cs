using System;
using System.Linq;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Lumina.Excel.Sheets;

namespace AdvertRunner;

public static class WorldHelper
{
    public static uint? GetCurrentWorldId()
    {
        var pc = Plugin.ObjectTable.LocalPlayer as IPlayerCharacter;
        return pc?.CurrentWorld.RowId;
    }

    public static string? GetCurrentWorldName()
    {
        var pc = Plugin.ObjectTable.LocalPlayer as IPlayerCharacter;
        return pc?.CurrentWorld.ValueNullable?.Name.ToString();
    }

    public static bool TryResolveWorldId(string input, out uint worldId)
    {
        worldId = 0;
        if (string.IsNullOrWhiteSpace(input))
            return false;

        var norm = Norm(input);

        var sheet = Plugin.DataManager.GameData.GetExcelSheet<World>();
        if (sheet is null)
            return false;

        foreach (var row in sheet)
        {
            var name = row.Name.ToString();
            if (string.IsNullOrWhiteSpace(name))
                continue;

            if (Norm(name) == norm)
            {
                worldId = row.RowId;
                return true;
            }
        }

        return false;
    }

    private static string Norm(string s)
        => new string((s ?? "")
            .Trim()
            .ToLowerInvariant()
            .Where(char.IsLetterOrDigit)
            .ToArray());
}
