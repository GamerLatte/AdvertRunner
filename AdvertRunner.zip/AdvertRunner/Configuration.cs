using Dalamud.Configuration;
using System;
using System.Collections.Generic;

namespace AdvertRunner;

[Serializable]
public sealed class Configuration : IPluginConfiguration
{
    public bool DebugLogging { get; set; } = false;
    public int Version { get; set; } = 1;
    public EndDestinationMode EndDestination { get; set; } = EndDestinationMode.None;
    //Only used when EndDestination == Custom
    public string CustomEndDestination { get; set; } = "";
    // Lists edited by the UI
    public List<string> Cities { get; set; } = new();

    // Macro settings edited by the UI
    public int MacroNumber { get; set; } = 2;

    /// <summary>"i" for individual, "s" for shared</summary>
    public string MacroBook { get; set; } = "i";

    public void Save() => Plugin.PluginInterface.SavePluginConfig(this);
    public bool ResumeAfterCrash { get; set; } = true;
    public RunState State { get; set; } = new();
    public WorldSelectionMode WorldMode { get; set; } = WorldSelectionMode.Worlds;
    public List<string> DataCenters { get; set; } = new();
    public List<string> Worlds { get; set; } = new();
}

public enum WorldSelectionMode
{
    Worlds = 0,
    DataCenters = 1,
}

public enum EndDestinationMode
{
    None = 0,
    Home = 1,
    Fc = 2,
    Custom = 3,
}

[Serializable]
public sealed class RunState
{
    public bool InProgress { get; set; }
    public int NextCityIndex { get; set; } = 0;
    public int NextWorldIndex { get; set; } = 0;

    // Optional sanity/debug
    public string? WorldNameAtCheckpoint { get; set; }
    public uint WorldIdAtCheckpoint { get; set; }
    public long LastCheckpointUnixSeconds { get; set; } = 0;

    public void Clear()
    {
        InProgress = false;
        NextCityIndex = 0;
        NextWorldIndex = 0;
        WorldNameAtCheckpoint = null;
        WorldIdAtCheckpoint = 0;
        LastCheckpointUnixSeconds = 0;
    }
}
