using System;
using System.Collections.Generic;
using System.Linq;

namespace AdvertRunner;

public static class WorldData
{
    // Data Center → Worlds mapping
    public static readonly IReadOnlyDictionary<string, string[]> DataCenters =
        new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
        {
            ["Aether"] = new[]
            {
                "Adamantoise",
                "Cactuar",
                "Faerie",
                "Gilgamesh",
                "Jenova",
                "Midgardsormr",
                "Sargatanas",
                "Siren",
            },

            ["Crystal"] = new[]
            {
                "Balmung",
                "Brynhildr",
                "Coeurl",
                "Diabolos",
                "Goblin",
                "Malboro",
                "Mateus",
                "Zalera",
            },

            ["Dynamis"] = new[]
            {
                "Cuchulainn",
                "Golem",
                "Halicarnassus",
                "Kraken",
                "Maduin",
                "Marilith",
                "Rafflesia",
                "Seraph",
            },

            ["Primal"] = new[]
            {
                "Behemoth",
                "Excalibur",
                "Exodus",
                "Famfrit",
                "Hyperion",
                "Lamia",
                "Leviathan",
                "Ultros",
            },
        };

    // ---------- Helpers used by the UI ----------

    public static string[] GetAllDataCenters()
        => DataCenters.Keys
            .OrderBy(x => x, StringComparer.OrdinalIgnoreCase)
            .ToArray();

    public static string[] GetAllWorlds()
        => DataCenters.Values
            .SelectMany(v => v)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(x => x, StringComparer.OrdinalIgnoreCase)
            .ToArray();

    // ---------- Helper used by RouteRunner ----------

    public static IEnumerable<string> ExpandDataCenters(IEnumerable<string> dcNames)
    {
        foreach (var raw in dcNames)
        {
            var dc = (raw ?? "").Trim();
            if (dc.Length == 0)
                continue;

            if (DataCenters.TryGetValue(dc, out var worlds))
            {
                foreach (var w in worlds)
                {
                    var world = (w ?? "").Trim();
                    if (world.Length > 0)
                        yield return world;
                }
            }
        }
    }
}
